#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <random>

namespace gazebo
{
  class ZombieMovement : public ModelPlugin
  {
  public:
    void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
    {
      this->model = _parent;
      this->lastUpdateTime = this->model->GetWorld()->SimTime();
      this->updateConnection = event::Events::ConnectWorldUpdateBegin(
          std::bind(&ZombieMovement::OnUpdate, this));
    }

    void OnUpdate()
    {
      common::Time currentTime = this->model->GetWorld()->SimTime();
      if ((currentTime - this->lastUpdateTime).Double() >= 10.0)
      {
        // // Generate random position within the range
        // double x = RandomDouble(0.5, 10.0); // Modify range as needed
        // double y = RandomDouble(0.5, 10.0); // Modify range as needed
        // this->model->SetWorldPose(ignition::math::Pose3d(x, y, 0.1, 0, 0, 0));
        // this->lastUpdateTime = currentTime;
      }
    }

  private:
    double RandomDouble(double min, double max)
    {
      std::random_device rd;
      std::mt19937 gen(rd());
      std::uniform_real_distribution<> dis(min, max);
      return dis(gen);
    }

    physics::ModelPtr model;
    event::ConnectionPtr updateConnection;
    common::Time lastUpdateTime;
  };

  GZ_REGISTER_MODEL_PLUGIN(ZombieMovement)
}