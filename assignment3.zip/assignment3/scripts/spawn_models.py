#!/usr/bin/python3

import rospy
from gazebo_msgs.srv import SpawnModel
from geometry_msgs.msg import Pose
import rospkg

def spawn_model(model_name, model_path, model_pose):
    rospy.wait_for_service('/gazebo/spawn_sdf_model')
    try:
        spawn_sdf_model = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        with open(model_path, 'r') as model_file:
            model_xml = model_file.read()
        spawn_sdf_model(model_name, model_xml, "/", model_pose, "world")
        rospy.loginfo(f"Spawned model: {model_name}")
    except rospy.ServiceException as e:
        rospy.logerr(f"Failed to spawn model: {model_name}, error: {e}")

if __name__ == '__main__':
    rospy.init_node('spawn_models', anonymous=True)

    rospack = rospkg.RosPack()
    package_path = rospack.get_path('assignment3')

    # Spawn zombies
    zombie_pose = Pose()
    zombie_pose.position.x = 8
    zombie_pose.position.y = 8
    zombie_pose.position.z = 0.1
    zombie_model_path = f"{package_path}/models/zombie/model.sdf"
    spawn_model("zombie1", zombie_model_path, zombie_pose)

    zombie_pose2 = Pose()
    zombie_pose2.position.x = 3
    zombie_pose2.position.y = 3
    zombie_pose2.position.z = 0.1
    zombie_model_path2 = f"{package_path}/models/zombie/model.sdf"
    spawn_model("zombie2", zombie_model_path2, zombie_pose2)

    zombie_pose3 = Pose()
    zombie_pose3.position.x = 7
    zombie_pose3.position.y = 7
    zombie_pose3.position.z = 0.1
    zombie_model_path3 = f"{package_path}/models/zombie/model.sdf"
    spawn_model("zombie3", zombie_model_path3, zombie_pose3)

    # Spawn ammo pot
    ammo_pot_pose = Pose()
    ammo_pot_pose.position.x = 8
    ammo_pot_pose.position.y = 5
    ammo_pot_pose.position.z = 0.1
    ammo_pot_model_path = f"{package_path}/models/ammo_pot/model.sdf"
    spawn_model("ammo_pot", ammo_pot_model_path, ammo_pot_pose)

    rospy.spin()
