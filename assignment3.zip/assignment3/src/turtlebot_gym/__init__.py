from gym.envs.registration import register

register(
    id='TurtleBotGymEnv-v0',
    entry_point='turtlebot_gym_env:TurtleBotGymEnv',
)

print("TurtleBotGymEnv registered.")