#!/usr/bin/python3

import rospy
from std_msgs.msg import String
import numpy as np
import tensorflow as tf

class AIInteraction:
    def __init__(self):
        # Initialize the node
        rospy.init_node('ai_interaction_node', anonymous=True)

        # Create subscribers for the agent's state and environment map
        self.state_sub = rospy.Subscriber('/agent_state', String, self.state_callback)
        self.map_sub = rospy.Subscriber('/environment_map', String, self.map_callback)

        # Create publisher for AI decisions
        self.decision_pub = rospy.Publisher('/ai_decision', String, queue_size=10)

        self.agent_state = None
        self.environment_map = None

        # Load the trained RL model
        self.model = tf.keras.models.load_model('/home/student/catkin_ws/src/assignment3/src/trained_global')

    def state_callback(self, data):
        rospy.loginfo(f"Received agent state: {data.data}")
        self.agent_state = np.fromstring(data.data.strip('[]'), sep=',')
        self.process_ai_decision()

    def map_callback(self, data):
        rospy.loginfo(f"Received environment map: {data.data}")
        self.environment_map = np.fromstring(data.data.strip('[]'), sep=',')
        self.process_ai_decision()

    def process_ai_decision(self):
        if self.agent_state is not None and self.environment_map is not None:
            rospy.loginfo("Processing AI decision")
            observation = self.agent_state
            action = np.argmax(self.model.predict(observation.reshape(1, -1)))
            decision = self.action_to_decision(action)
            self.decision_pub.publish(decision)
            rospy.loginfo(f"Published AI decision: {decision}")

    def action_to_decision(self, action):
        if action == 0:
            return "move_up"
        elif action == 1:
            return "move_down"
        elif action == 2:
            return "move_left"
        elif action == 3:
            return "move_right"

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        ai_interaction = AIInteraction()
        ai_interaction.run()
    except rospy.ROSInterruptException:
        pass
