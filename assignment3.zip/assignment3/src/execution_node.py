#!/usr/bin/python3

import rospy
from std_msgs.msg import String
from gazebo_msgs.srv import GetModelState, SetModelState
from gazebo_msgs.msg import ModelState

class ExecutionNode:
    def __init__(self):
        rospy.init_node('execution_node', anonymous=True)
        self.decision_sub = rospy.Subscriber('/ai_decision', String, self.decision_callback)
        
        rospy.wait_for_service('/gazebo/get_model_state')
        self.get_model_state = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        
        rospy.wait_for_service('/gazebo/set_model_state')
        self.set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)

    def decision_callback(self, data):
        rospy.loginfo(f"Received AI decision: {data.data}")
        self.convert_decision_to_command(data.data)

    def convert_decision_to_command(self, decision):
        try:
            current_state = self.get_model_state('turtlebot3_burger', '')
            current_pose = current_state.pose

            new_x, new_y = current_pose.position.x, current_pose.position.y

            if decision == "move_up":
                new_x += 0.5
            elif decision == "move_down":
                new_x -= 0.5
            elif decision == "move_left":
                new_y -= 0.5
            elif decision == "move_right":
                new_y += 0.5

            if self.is_near_zombie(new_x, new_y):
                rospy.loginfo("Zombie hunted!")
                self.handle_zombie_hunting(new_x, new_y)

            elif self.is_near_pot(new_x, new_y):
                rospy.loginfo("Reached the pot!")
                self.handle_reaching_pot(new_x, new_y)

            elif not self.is_within_bounds(new_x, new_y):
                rospy.loginfo("Hit boundary! Failure.")
                self.handle_boundary_hit()

            else:
                self.move_to_new_position(new_x, new_y, current_pose.orientation)

        except rospy.ServiceException as e:
            rospy.logerr(f"Service call failed: {e}")

    def is_near_zombie(self, x, y):
        for zombie in ['zombie1', 'zombie2', 'zombie3']:
            zombie_state = self.get_model_state(zombie, '')
            if self.calculate_distance(x, y, zombie_state.pose.position.x, zombie_state.pose.position.y) < 1.0:
                return True
        return False

    def is_near_pot(self, x, y):
        pot_state = self.get_model_state('ammo_pot', '')
        return self.calculate_distance(x, y, pot_state.pose.position.x, pot_state.pose.position.y) < 1.0

    def is_within_bounds(self, x, y):
        return 0 <= x <= 10 and 0 <= y <= 10

    def calculate_distance(self, x1, y1, x2, y2):
        return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

    def handle_zombie_hunting(self, x, y):
        for zombie in ['zombie1', 'zombie2', 'zombie3']:
            self.delete_model(zombie)
        self.move_to_new_position(x, y)

    def handle_reaching_pot(self, x, y):
        self.move_to_new_position(x, y)
        rospy.signal_shutdown("Simulation complete: Reached the pot.")

    def handle_boundary_hit(self):
        rospy.loginfo("Boundary hit, ending simulation.")
        rospy.signal_shutdown("Simulation complete: Failure due to boundary hit.")

    def move_to_new_position(self, x, y, orientation):
        state_msg = ModelState()
        state_msg.model_name = 'turtlebot3_burger'
        state_msg.pose.position.x = x
        state_msg.pose.position.y = y
        state_msg.pose.position.z = 0.1
        state_msg.pose.orientation = orientation
        self.set_model_state(state_msg)
        rospy.loginfo(f"Moved to new position: ({x}, {y})")

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        execution_node = ExecutionNode()
        execution_node.run()
    except rospy.ROSInterruptException:
        pass
