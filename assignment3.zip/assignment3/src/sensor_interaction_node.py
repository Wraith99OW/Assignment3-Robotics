#!/usr/bin/python3

import rospy
from sensor_msgs.msg import LaserScan

class SensorInteraction:
    def __init__(self):
        rospy.init_node('sensor_interaction_node', anonymous=True)
        self.lidar_sub = rospy.Subscriber('/scan', LaserScan, self.lidar_callback)
        self.lidar_pub = rospy.Publisher('/processed_lidar', LaserScan, queue_size=10)

    def lidar_callback(self, data):
        rospy.loginfo("LIDAR data received")
        self.lidar_pub.publish(data)

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        sensor_interaction = SensorInteraction()
        sensor_interaction.run()
    except rospy.ROSInterruptException:
        pass
