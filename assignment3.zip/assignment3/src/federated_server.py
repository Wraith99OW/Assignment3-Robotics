import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
from flask import Flask, request, jsonify
import threading

app = Flask(__name__)

global_model = tf.keras.Sequential([
    layers.Input(shape=(360,)),
    layers.Dense(128, activation='relu'),
    layers.Dense(128, activation='relu'),
    layers.Dense(4, activation='linear')
])

global_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                     loss='mse')

lock = threading.Lock()

@app.route('/update_model', methods=['POST'])
def update_model():
    data = request.get_json()
    weights = [np.array(w) for w in data['weights']]
    
    with lock:
        global_model.set_weights(weights)

    return jsonify({"status": "success"})

@app.route('/get_model', methods=['GET'])
def get_model():
    with lock:
        weights = global_model.get_weights()
    
    return jsonify({"weights": [w.tolist() for w in weights]})

@app.route('/save_model', methods=['POST'])
def save_model():
    with lock:
        global_model.save('/home/student/catkin_ws/src/assignment3/src/trained_global')
    return jsonify({"status": "model saved"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
