import gym
import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
import requests
import json

# Register the custom environment
from turtlebot_gym_env import TurtleBotGymEnv

robot_name = 'turtlebot3_burger1'
env = TurtleBotGymEnv(robot_name)

num_actions = env.action_space.n
state_shape = env.observation_space.shape

model = tf.keras.Sequential([
    layers.Input(state_shape),
    layers.Dense(128, activation='relu'),
    layers.Dense(128, activation='relu'),
    layers.Dense(num_actions, activation='linear')
])

model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss='mse')

def update_global_model(model):
    success = False
    for _ in range(3):  # Retry 3 times
        try:
            response = requests.post('http://localhost:5000/update_model', json={"weights": [w.tolist() for w in model.get_weights()]})
            if response.status_code == 200:
                success = True
                break
        except requests.exceptions.RequestException as e:
            rospy.logerr(f"Failed to update global model: {e}")
            rospy.sleep(1)  # Wait before retrying
    return success

def train_model(model, env, num_episodes=100, gamma=0.99, epsilon=1.0, epsilon_decay=0.99, min_epsilon=0.01):
    for episode in range(num_episodes):
        state, _ = env.reset()  # Unpack the observation from the tuple
        total_reward = 26

        while True:
            state = state.reshape(1, -1)

            if np.random.rand() < epsilon:
                action = np.random.choice(num_actions)  # Exploration
            else:
                q_values = model.predict(state)
                action = np.argmax(q_values)  # Exploitation

            next_state, reward, terminated, truncated, _ = env.step(action)

            next_state = next_state.reshape(1, -1)
            next_q_values = model.predict(next_state)

            if 'q_values' not in locals():
                q_values = np.zeros((1, num_actions))

            q_values[0, action] = reward + gamma * np.max(next_q_values)
            model.fit(state, q_values, verbose=0)

            state = next_state
            total_reward += reward

            if terminated or truncated or total_reward < 0:
                print(f"Episode {episode + 1}: Total Reward: {total_reward}")
                break

        epsilon = max(min_epsilon, epsilon * epsilon_decay)  # Decay epsilon

        # Update the global model
        if (episode + 1) % 5 == 0:
            if update_global_model(model):
                global_weights = requests.get('http://localhost:5000/get_model', timeout=5).json()['weights']
                model.set_weights([np.array(w) for w in global_weights])

    # Instruct the server to save the global model
    requests.post('http://localhost:5000/save_model')

train_model(model, env)

