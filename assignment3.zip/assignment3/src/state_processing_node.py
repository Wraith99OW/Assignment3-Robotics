#!/usr/bin/python3

import rospy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
import numpy as np

class StateProcessing:
    def __init__(self):
        rospy.init_node('state_processing_node', anonymous=True)
        self.lidar_sub = rospy.Subscriber('/processed_lidar', LaserScan, self.lidar_callback)
        self.state_pub = rospy.Publisher('/agent_state', String, queue_size=10)
        self.map_pub = rospy.Publisher('/environment_map', String, queue_size=10)
        self.environment_map = None
        self.agent_state = None

    def lidar_callback(self, data):
        self.environment_map = self.process_lidar_data(data)
        rospy.loginfo(f"Updated environment map: {self.environment_map}")
        self.map_pub.publish(self.environment_map)

        self.agent_state = self.process_lidar_state(data)
        rospy.loginfo(f"Updated agent state: {self.agent_state}")
        self.state_pub.publish(self.agent_state)

    def process_lidar_data(self, data):
        ranges = np.array(data.ranges)
        occupancy_grid = (ranges < 1.0).astype(int)
        return str(occupancy_grid.tolist())

    def process_lidar_state(self, data):
        ranges = np.array(data.ranges)
        state = []
        for r in ranges:
            if r < 1.0:
                state.append(1)
            else:
                state.append(0)
        return str(state)

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        state_processing = StateProcessing()
        state_processing.run()
    except rospy.ROSInterruptException:
        pass
