import gym
from gym import spaces
import numpy as np
import rospy
import random
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from gazebo_msgs.srv import GetModelState, SetModelState, SetModelStateRequest, SpawnModel, DeleteModel
from gazebo_msgs.msg import ModelState

class TurtleBotGymEnv(gym.Env):
    def __init__(self, robot_name):
        super(TurtleBotGymEnv, self).__init__()
        self.robot_name = robot_name
        # Initialize ROS node
        rospy.init_node(f'{robot_name}_gym_env', anonymous=True)
        print(f"ROS node for {self.robot_name} initialized.")

        # Define action and observation space
        self.action_space = spaces.Discrete(4)  # 0: Move up, 1: Move down, 2: Move left, 3: Move right
        self.observation_space = spaces.Box(low=0.0, high=1.0, shape=(360,), dtype=np.float32)
        print("Action space and observation space defined.")

        # Publishers and subscribers
        self.cmd_pub = rospy.Publisher(f'/{self.robot_name}/cmd_vel', Twist, queue_size=10)
        self.lidar_sub = rospy.Subscriber(f'/{self.robot_name}/scan', LaserScan, self.lidar_callback)
        self.lidar_data = np.zeros(360, dtype=np.float32)

        # Service proxies
        rospy.wait_for_service('/gazebo/get_model_state')
        rospy.wait_for_service('/gazebo/set_model_state')
        rospy.wait_for_service('/gazebo/spawn_sdf_model')
        rospy.wait_for_service('/gazebo/delete_model')
        self.get_model_state = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
        self.spawn_model = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        self.delete_model = rospy.ServiceProxy('/gazebo/delete_model', DeleteModel)
        print("Service proxies created.")

        self.zombies = ['zombie1', 'zombie2', 'zombie3']
        self.zombie_positions = {
            'zombie1': (8, 8),
            'zombie2': (3, 3),
            'zombie3': (7, 7)
        }

        rospy.loginfo(f"{self.robot_name} GymEnv initialized.")

    def step(self, action):
        current_state = self.get_model_state(self.robot_name, '')
        current_pose = current_state.pose

        new_x, new_y = current_pose.position.x, current_pose.position.y

        if action == 0:  # Move up
            new_x += 0.5
        elif action == 1:  # Move down
            new_x -= 0.5
        elif action == 2:  # Move left
            new_y -= 0.5
        elif action == 3:  # Move right
            new_y += 0.5

        # Check if the new position is within the grid boundaries
        if 0 <= new_x <= 10 and 0 <= new_y <= 10:
            state_msg = ModelState()
            state_msg.model_name = self.robot_name
            state_msg.pose.position.x = new_x
            state_msg.pose.position.y = new_y
            state_msg.pose.position.z = 0.1
            state_msg.pose.orientation = current_pose.orientation
            self.set_model_state(state_msg)
            terminated = False
        else:
            # Penalize and end the episode if the robot hits a boundary
            reward = -200  # Strong penalty
            observation = self.lidar_data if self.lidar_data is not None else np.zeros(360, dtype=np.float32)
            terminated = True
            truncated = False
            info = {}
            return observation, reward, terminated, truncated, info

        rospy.sleep(0.1)

        reward = self.compute_reward(new_x, new_y)
        observation = self.lidar_data if self.lidar_data is not None else np.zeros(360, dtype=np.float32)
        terminated = self.is_done(new_x, new_y)
        truncated = False
        info = {}

        return observation, reward, terminated, truncated, info

    def reset(self):

        y_offset = random.uniform(-4, 4)

        state_msg = ModelState()
        state_msg.model_name = self.robot_name
        state_msg.pose.position.x = 5  # Start at the center of the grid
        state_msg.pose.position.y = 5 + y_offset
        state_msg.pose.position.z = 0.1
        state_msg.pose.orientation.x = 0
        state_msg.pose.orientation.y = 0
        state_msg.pose.orientation.z = 0
        state_msg.pose.orientation.w = 1
        self.set_model_state(state_msg)

        rospy.sleep(1)

        self.zombies = ['zombie1', 'zombie2', 'zombie3']  # Reset zombies

        for zombie in self.zombies:
            self.delete_model(zombie)
        for zombie in self.zombies:
            self.spawn_zombie(zombie, *self.zombie_positions[zombie])

        rospy.loginfo(f"{self.robot_name} environment reset.")
        return np.zeros(360, dtype=np.float32), {}

    def lidar_callback(self, data):
        self.lidar_data = np.array(data.ranges, dtype=np.float32)

    def compute_reward(self, x, y):
        reward = 0

        # Collision penalty
        if self.lidar_data is not None and np.any(self.lidar_data < 0.5) and not self.is_near_pot(x, y) and not self.is_near_robot(x, y):
            reward -= -100  # Collision penalty

        # Safe movement negative reward
        reward -= 2  # Safe movement reward

        if self.is_near_pot(x, y):
            reward += 300

        # Reward for hunting zombies
        for zombie in self.zombies:
            if self.is_near_zombie(x, y, zombie):
                reward += 90
                self.zombies.remove(zombie)
                self.delete_model(zombie)

        # Reward for killing all zombies
        if not self.zombies:
            reward += 10

        return reward

    def is_near_zombie(self, x, y, zombie_name):
        # Check proximity to a zombie
        zombie_state = self.get_model_state(zombie_name, '')
        distance = self.calculate_distance(x, y, zombie_state.pose.position.x, zombie_state.pose.position.y)
        return distance < 2.0

    def is_near_pot(self, x, y):
        # Check proximity to the pot
        pot_state = self.get_model_state('ammo_pot', '')
        distance = self.calculate_distance(x, y, pot_state.pose.position.x, pot_state.pose.position.y)
        return distance <= 1
    
    def is_near_robot(self, x, y):
        for other_robot in ['turtlebot3_burger1', 'turtlebot3_burger3', 'turtlebot3_burger3']:
            if other_robot != self.robot_name:
                robot_state = self.get_model_state(other_robot, '')
                distance = self.calculate_distance(x, y, robot_state.pose.position.x, robot_state.pose.position.y)
                return distance <= 1.0

    def calculate_distance(self, x1, y1, x2, y2):
        dx = x1 - x2
        dy = y1 - y2
        return np.sqrt(dx**2 + dy**2)

    def is_done(self, x, y):
        if self.is_near_pot(x, y) or (self.lidar_data is not None and np.any(self.lidar_data < 0.5) and not self.is_near_robot(x, y)):
            return True
        return False

    def spawn_zombie(self, name, x, y):
        # Load zombie model XML
        with open('/home/student/catkin_ws/src/assignment3/models/zombie/model.sdf', 'r') as f:
            model_xml = f.read()

        initial_pose = ModelState()
        initial_pose.model_name = name
        initial_pose.pose.position.x = x
        initial_pose.pose.position.y = y
        initial_pose.pose.position.z = 0.1

        self.spawn_model(name, model_xml, "", initial_pose.pose, "world")
